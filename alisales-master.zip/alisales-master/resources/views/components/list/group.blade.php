<ul class="list-group list-group-unbordered mb-3">
    {{$slot}}
</ul>
