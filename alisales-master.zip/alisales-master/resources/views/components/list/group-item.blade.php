<li class="list-group-item">
    <b>{{__($label)}}</b>
    <span class="float-right">{{$slot}}</span>
</li>
