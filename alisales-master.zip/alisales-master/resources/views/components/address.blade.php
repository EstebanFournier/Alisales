{{$address}}<br>
{{$postalCode}} - {{$city}}
<a href="https://www.openstreetmap.org/search?query={{$query}}" target="_blank">
    <i class="fa fa-search-location"></i>
</a>
