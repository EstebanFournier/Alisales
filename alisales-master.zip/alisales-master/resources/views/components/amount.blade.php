<span class="amount float-right">
    {{number_format($amount,2,',',' ')}} €

</span>
