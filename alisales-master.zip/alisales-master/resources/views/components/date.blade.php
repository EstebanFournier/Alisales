<span class="date">
    {{$date->formatLocalized('%x')}}
</span>
